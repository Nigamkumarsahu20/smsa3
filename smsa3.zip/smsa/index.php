
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <section class="login-container">


        <h2>Welcome </br> Student Management System</h2>


    <ul>
        <li><a href="student_login.php?type=Student">Login as Student</a></li>
        <li><a href="teacher_login.php?type=Teacher">Login as Teacher</a></li>
        <li><a href="admin_login.php?type=Admin">Login as Admin</a></li>
        <!-- Add more navigation links based on your project modules -->
    </ul>

    </section>
</body>

</html>
