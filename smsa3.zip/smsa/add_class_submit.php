<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Personal Information
    $class_name = $_POST["class_name"];
    $section = $_POST["section"];
    

    // Insert data into the database
    $sql = "INSERT INTO class (class_name, section)
            VALUES ('$class_name', '$section')";

    if ($conn->query($sql) === TRUE) {
        echo "Class  information submitted successfully!";
        header("Location: add_class.php"); // Redirect to the student dashboard or home page

    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

?>
