<?php
include 'db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Personal Information
    $firstName = $_POST["FirstName"];
    $lastName = $_POST["LastName"];
    $dateOfBirth = $_POST["DateOfBirth"];
    $gender = $_POST["Gender"];
    $nationality = $_POST["Nationality"];
    $specialization = $_POST["Specialization"];
    

    // User Authentication
    $username = $_POST["Username"];
    $passwordHash = password_hash($_POST["PasswordHash"], PASSWORD_DEFAULT);

    // Additional Optional Fields
   
    // Insert data into the database
    $sql = "INSERT INTO admin (FirstName, LastName, DateOfBirth, Gender, Nationality,
            Username, PasswordHash,Specialization)
            VALUES ('$firstName', '$lastName', '$dateOfBirth', '$gender', '$nationality',
            '$username', '$passwordHash','$specialization')";

    if ($conn->query($sql) === TRUE) {
        echo "Admin information submitted successfully!";
        header("Location: admin_register.php"); // Redirect to the student dashboard or home page

    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

?>
