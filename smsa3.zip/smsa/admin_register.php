<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Register  Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
      width: 300px; /* Set the width of the form */
      margin: 50px auto; /* Center the form on the page */
      padding: 20px; /* Add some padding for better visual */
      border: 1px solid #ccc; /* Add a border for better visual */
    }

        label {
            display: block;
            margin-bottom: 5px;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>


    <form action="admin_register_submit.php" method="post">
    <h2>Admin Information Form</h2>

        <!-- Personal Information -->
        <label for="firstName">First Name:</label>
        <input type="text" id="firstName" name="FirstName" required>
        <label for="lastName">Last Name:</label>
        <input type="text" id="lastName" name="LastName" required>
        <label for="dateOfBirth">Date of Birth:</label>
        <input type="date" id="dateOfBirth" name="DateOfBirth" required>
        <label>Gender:</label>
        <select id="gender" name="Gender" required>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select>
        <label for="nationality">Nationality:</label>
        <input type="text" id="nationality" name="Nationality">
        <label for="passwordHash">Specialization</label>
        <input type="password" id="specialization" name="Specialization" required>
      
        <label for="username">Username:</label>
        <input type="text" id="username" name="Username" required>
        <label for="passwordHash">Password :</label>
        <input type="password" id="passwordHash" name="PasswordHash" required>
      
        <!-- Submit Button -->
        <button type="submit" name=”submit”>Submit</button>
    </form>
</body>
</html>
