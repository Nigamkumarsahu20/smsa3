<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<section class="login-container">


    <h2>Admin Login</h2>

    <?php
    // Display error message if any
    if (isset($_GET['error'])) {
        $error = $_GET['error'];
        echo "<p class='error'>$error</p>";
    }
    ?>

    <form action="admin_login_submit.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <input type="hidden" name="userType" value="admin">

        <input type="submit" value="Login">
    </form>

    <p>Not registered? <a href="admin_register.php?type=admin">Register here</a></p>
</section>
</body>
</html>
