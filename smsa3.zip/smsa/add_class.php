
<?php
include "db.php";
include "header.php";
include "admin_sidebar.php"; 

?>

<div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
    <div class="container-fluid"></div>
    <div class="container-fluid"></div>
      <div class="row" ></div>
      <div class="row" >
                    <div class="col-xl-4 col-lg-4 col-md-12 col-12" style="padding-top: 60px;padding-left: 60px;">
                    <div class="card" style="padding-top: 30px;">
            <h6 class="card-header" style="padding-top: 10px;"> New CLASS Form</h6>
            <div class="card-body">
            <form method="POST" action="add_class_submit.php">
            <div class="form-group">
                        <label for="inputUserName"> ADD CLASS</label>
                        <input class="form-control form-control-lg" name="class_name"  id="class" type="text" >
                    </div>
                    <div class="form-group">
                        <label for="inputUserName"> ADD SECTION</label>
                        <input class="form-control form-control-lg" name="section"  id="class" type="text" >
                    </div>

                    <button type="submit" name="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                </form>

                </div>
                </div>
            </div>
            </div>
            </div>
            </section>
                <?php include("footer.php"); ?>
            </div>
