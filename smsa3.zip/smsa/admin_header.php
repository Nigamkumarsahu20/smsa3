<header>
                <div class="row">
                <div class="col-md-10">

                    <h1>Welcome to the Admin</h1></div>                 
                    <div class="col-md-2">

                    <a href="logout.php">Logout</a></div>
                </div>

                </header>